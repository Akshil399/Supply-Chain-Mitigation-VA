
import streamlit as st
import os
from transformers import AutoTokenizer, AutoModel
from sentence_transformers import SentenceTransformer
from langchain.llms import HuggingFaceHub
from langchain.prompts import PromptTemplate
from langchain.vectorstores import FAISS
from langchain.document_loaders import PyPDFLoader, CSVLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import ConversationalRetrievalChain
from langchain_community.document_loaders import UnstructuredURLLoader
from langchain_community.embeddings import HuggingFaceEmbeddings

# Streamlit App
st.title("Supply Chain Mitigation Information")

# Set Hugging Face API Token
os.environ["HUGGINGFACEHUB_API_TOKEN"] = "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"

# Load Documents
pdf_path = r"D:\supply chain mitigation va\PaulSteve-thesis_removed.pdf"
pdf_path2 = r"D:\supply chain mitigation va\Supply Chain mit 1st research paper_removed.pdf"
csv_path = r"D:\supply chain mitigation va\ResilienceIndexRegions-2024.csv"
csv_path2 = r"D:\supply chain mitigation va\tot sup excel.csv"
csv_path4 = r"D:\supply chain mitigation va\WB_DoingBusiness_2018-20.csv"

urls = ['https://www.netsuite.com/portal/resource/articles/inventory-management/supply-chain-risks.shtml']

# Document Loading
@st.cache_data
def load_documents():
    url_loader = UnstructuredURLLoader(urls=urls)
    url_docs = url_loader.load()

    pdf_loader = PyPDFLoader(pdf_path)
    pdf_docs = pdf_loader.load()
    pdf_loader2 = PyPDFLoader(pdf_path2)
    pdf_docs2 = pdf_loader2.load()

    csv_loader = CSVLoader(file_path=csv_path, encoding='ISO-8859-1')
    csv_docs = csv_loader.load()
    csv_loader2 = CSVLoader(file_path=csv_path2, encoding='ISO-8859-1')
    csv_docs2 = csv_loader2.load()
    csv_loader4 = CSVLoader(file_path=csv_path4, encoding='ISO-8859-1')
    csv_docs4 = csv_loader4.load()

    all_docs = url_docs + pdf_docs + csv_docs + pdf_docs2 + csv_docs2 + csv_docs4
    return all_docs

docs = load_documents()

# Text Splitting
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
split_docs = text_splitter.split_documents(docs)

# Embedding and Vectorstore
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
vectorstore = FAISS.from_documents(split_docs, embeddings)
retriever = vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 3})

# LLM Initialization
llm = HuggingFaceHub(
    repo_id="meta-llama/Llama-3.2-3B-Instruct",
    model_kwargs={"temperature": 0.5, "max_new_tokens": 200}
)
prompt_template = """
You are a helpful assistant. Use the context below to answer the question:

{context}

Question: {question}
Answer:
"""

prompt = PromptTemplate(
    input_variables=["context", "question"],
    template=prompt_template,
)



# Create Retrieval Chain
qa_chain = ConversationalRetrievalChain.from_llm(
    llm=llm,
    retriever=retriever,
    return_source_documents=False,
    combine_docs_chain_kwargs={"prompt": prompt}
)

# User Input
question = st.text_input("Ask a question about Supply Chain Information:")
if question:
    response = qa_chain({"question": question, "chat_history": []})
    # Extract only the answer
    full_response = response["answer"]
    if "Answer:" in full_response:
        answer = full_response.split("Answer:")[1].strip()
    else:
        answer = full_response
    st.write(answer)